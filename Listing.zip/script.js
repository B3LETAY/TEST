window.addEventListener('DOMContentLoaded', function(){
    let sel = document.querySelectorAll('.select');
    let reg = document.querySelector('#reg');
    let log = document.querySelector('#log');
    let reg2 = document.querySelector('#reg2');
    let log2 = document.querySelector('#log2');
    let back = document.querySelectorAll('.back');
    function func_tog(){
        sel.forEach((e) => {e.classList.toggle('visible-none', true)});
    }
    reg.addEventListener('click', function(e){
        func_tog();
        sel[0].classList.remove('visible-none', false);
        sel[1].classList.remove('visible-none', false);
        console.log('reg');
    })
    log.addEventListener('click', function(e){
        func_tog();
        sel[0].classList.remove('visible-none', false);
        sel[2].classList.remove('visible-none', false);
        console.log('log');
    })
    reg2.addEventListener('click', function(e){
        func_tog();
        sel[0].classList.remove('visible-none', false);
        sel[1].classList.remove('visible-none', false);
        console.log('reg');
    })
    log2.addEventListener('click', function(e){
        func_tog();
        sel[0].classList.remove('visible-none', false);
        sel[2].classList.remove('visible-none', false);
        console.log('log');
    })
    back.forEach((e) => {e.addEventListener('click', function(e){func_tog()})})
})