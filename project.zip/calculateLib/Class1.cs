﻿namespace calculateLib
{
    public class Figure
    {
        public double circle(double rad)
        {
            return Math.PI * Math.Pow(rad, 2);
        }

        public void polygon(params double[] side)
        {
            switch (side.Length)
            {
                case 3: triangle(side[0], side[1], side[2]);
                    break;
                /*case 4: quadrilateral(side[0], side[1], side[2], side[3]); // пример добавления фигур
                    break;*/
                default:
                    break;
            }
        }

        private double triangle(double a, double b, double c)
        {
            if (Math.Pow(a, 2) + Math.Pow(b, 2) == Math.Pow(c, 2)) //проверка на прямоугольный треугольник
            {
                return (a * b) / 2;
            }
            else if (a == b && a == c) //проверка на равносторонний треугольник
            {
                return (a * Math.Sqrt(Math.Pow(a / 2, 2) + Math.Pow(b, 2))) / 2;
            }
            else if (b == c) //проверка на равнобедренный треугольник
            {
                return (a * Math.Sqrt(Math.Pow(a / 2, 2) + Math.Pow(b, 2))) / 2;
            }
            else
            {
                double p = (a + b + c) / 2;
                return Math.Sqrt(p * (p - a) * (p - b) * (p - c));
            }
        }

        /*private double quadrilateral(double a, double b, double c, double d)
        {
            if (a == b)
            {
                return a * a;
            }
            else if (a == c && b == d)
            {
                return a * b;
            }
            return 0;
        }*/


    }

}