﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using calcLib;

namespace project
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine(Figure.circle(5));
            Console.WriteLine(Figure.polygon(3, 4, 5));


            Console.ReadKey();
        }
    }
}
